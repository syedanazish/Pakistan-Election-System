import java.io.*; 
import java.net.*; 
public class ClientCommunicator { 
    private static final String SERVER_IP = "10.56.124.60";  
    private static final int SERVER_PORT = 12345; 
 
    public static String sendMessage(String message) { 
        try (Socket socket = new Socket(SERVER_IP, SERVER_PORT); 
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true); 
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) { 
 
            out.println(message); 
            String response = in.readLine(); 
            return response; 
 
        } catch (IOException e) { 
            return "ERROR;Network error: " + e.getMessage(); 
        } 
    } 
}