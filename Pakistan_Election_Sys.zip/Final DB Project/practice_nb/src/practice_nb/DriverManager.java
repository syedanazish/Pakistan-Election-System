/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practice_nb;

import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author ATECH
 */
class DriverManager {

    static Connection getConnection(String jdbcmysqllocalhost3306yourDB, String root, String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
