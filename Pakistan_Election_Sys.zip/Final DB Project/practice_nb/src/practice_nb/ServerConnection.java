package practice_nb;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;

public class ServerConnection {
    public static Socket socket;
    public static PrintWriter out;
    public static BufferedReader in;
    
                private static final String SERVER_IP = "localhost";  


    public static void connectToServer() {

        try {
            socket = new Socket(SERVER_IP, 12345);
            out = new PrintWriter(socket.getOutputStream(),true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            System.out.println("Connected to server successfully.");
        } catch (IOException e) {
             e.printStackTrace(); 
            JOptionPane.showMessageDialog(null, "Error connecting to server: " + e.getMessage(),
                    "Connection Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }
    public static void closeConnection(){
        try{
            ServerConnection.out.close();
            ServerConnection.in.close();
            ServerConnection.socket.close();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}
