package server_connection;


import java.io.*;
import static java.lang.System.out;
import java.net.*;
import java.sql.*;
import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter; 
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

public class ServerSide_1 {
    private static final int PORT = 12345;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started and listening on port " + PORT);
            while (true) {
                try (Socket socket = serverSocket.accept()) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    System.out.println("Connect with client IP "+socket.getInetAddress());
                    String request = in.readLine();                  
                    String[] parts = request.split(";", 2);
                    String command = parts[0];
                    String data = parts.length > 1 ? parts[1] : "";
                    String response = handleCommand(command.toLowerCase(), data);                  
                    out.println(response);
                    
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/pak_election";
        String user = "root";
        String password = "DBproject#4";
        return DriverManager.getConnection(url, user, password);
    }
     

    private static String handleCommand(String command, String data) {        
        switch (command) {
            case "@":
                return insertVoter(data);
            case "update":
                return updateVoter(data);
            case "delete":
                return deleteVoter(data);
            case "getall":
                return getAllVoters();
            case "$":
                return insertParty(data);
            case "$$":
                return updateParty(data);
            case "$$$":
                return deleteParty(data);
            case "getall_party":
                return getAllParties();
            case "#":
                return insertCandidate(data);
            case "##":
                return updateCandidate(data);
            case "###":
                return deleteCandidate(data);
            case "getall_candidates":
                return getAllCandidates();
            case "$&^":
                return login(data);//login 
                case "castvote":
                return insertVote(data);
            case "getall_votes":
                return getAllVotes();
                case "calculate_results":
                return calculateAndSaveResults();
            case "fetchElectionResults":
                return fetchElectionResults();
                case "verify_voter":
    return verifyVoter(data);
            default:
                return "Invalid Command";
        }
    }

    // ----- VOTER METHODS -----

    private static String login (String data) {
        String[] loginData = data.split(",");
        String loginCNIC = loginData[0];
        String loginPassword = loginData[1];
        try (Connection conn = getConnection();
            PreparedStatement pstmt = conn.prepareStatement("Select role FROM login_users WHERE cnic = ? AND password =?")) {            
            pstmt.setString(1, loginCNIC);
            pstmt.setString(2, loginPassword);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String role = rs.getString("role");               
                return role;
            } else {
                return "error;Invalid credentials";
            }                       
        } catch (SQLException e) {
            return "error;" + e.getMessage();
        }
    }

    
    private static String insertVoter(String data) {
        System.out.println(data);
        String[] fields = data.split(",");
        if (fields.length != 6) return "Invalid Data for Voter";
        try (Connection conn = getConnection();
            CallableStatement stmt = conn.prepareCall("{CALL InsertVoter(?,?,?,?,?,?)}")) {
            stmt.setString(1, fields[0]);            
            stmt.setString(2, fields[1]);            
            stmt.setInt(3, Integer.parseInt(fields[2]));          
            stmt.setString(4, fields[3]);
            stmt.setString(5, fields[4]);
            stmt.setString(6, fields[5]);
            int rows = stmt.executeUpdate();
            if(rows>0)
                return "Voter Inserted Successfully";
            else
                return "VOter not inserted";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String updateVoter(String data) {
        String[] fields = data.split(",");
        if (fields.length != 6) return "Invalid Data for Voter Update";
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL UpdateVoter(?,?,?,?,?,?)}")) {
            stmt.setString(1, fields[0]);
            stmt.setString(2, fields[1]);
            stmt.setInt(3, Integer.parseInt(fields[2]));
            stmt.setString(4, fields[3]);
            stmt.setString(5, fields[4]);
            stmt.setString(6, fields[5]);
            stmt.executeUpdate();
            return "Voter Updated Successfully";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String deleteVoter(String data) {
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL DeleteVoter(?)}")) {
            stmt.setString(1, data.trim());
            stmt.executeUpdate();
            return "Voter Deleted Successfully";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    
    private static String getAllVoters() {
        StringBuilder sb = new StringBuilder();
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL GetAllVoters()}");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                sb.append(rs.getString("votercnic")).append(",")
                        .append(rs.getString("votername")).append(",")
                        .append(rs.getInt("voterage")).append(",")
                        .append(rs.getString("gender")).append(",")
                        .append(rs.getString("voterpassword")).append(",")
                        .append(rs.getString("seatnumber")).append("\n");
            }
            return sb.toString();
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    // ----- PARTY METHODS -----

    private static String insertParty(String data) {
        String[] fields = data.split(",");
        if (fields.length != 4) return "Invalid Data for Party";
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL InsertParty(?,?,?,?)}")) {
            stmt.setInt(1, Integer.parseInt(fields[0]));
            stmt.setString(2, fields[1]);
            stmt.setString(3, fields[2]);
            stmt.setString(4, fields[3]);
            stmt.executeUpdate();
            return "Party Inserted Successfully";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String updateParty(String data) {
        String[] fields = data.split(",");
        if (fields.length != 4) return "Invalid Data for Party Update";
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL UpdateParty(?,?,?,?)}")) {
            stmt.setInt(1, Integer.parseInt(fields[0]));
            stmt.setString(2, fields[1]);
            stmt.setString(3, fields[2]);
            stmt.setString(4, fields[3]);
            stmt.executeUpdate();
            return "Party Updated Successfully";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String deleteParty(String data) {
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL DeleteParty(?)}")) {
            stmt.setInt(1, Integer.parseInt(data.trim()));
            stmt.executeUpdate();
            return "Party Deleted Successfully";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String getAllParties() {
        StringBuilder sb = new StringBuilder();
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL GetAllParties()}");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                sb.append(rs.getInt("partyid")).append(",")
                        .append(rs.getString("partyname")).append(",")
                        .append(rs.getString("symbol")).append(",")
                        .append(rs.getString("leadername")).append("\n");
            }
            return sb.toString();
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    // ----- CANDIDATE METHODS -----

    private static String insertCandidate(String data) {
        String[] fields = data.split(",");
        if (fields.length != 4) return "Invalid Data for Candidate";
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL InsertCandidate(?,?,?,?)}")) {
            stmt.setString(1, fields[0]);
            stmt.setString(2, fields[1]);
            stmt.setInt(3, Integer.parseInt(fields[2]));
            stmt.setString(4, fields[3]);
            stmt.executeUpdate();
            return "Candidate Inserted Successfully";
            
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String updateCandidate(String data) {
        String[] fields = data.split(",");
        if (fields.length != 4) return "Invalid Data for Candidate Update";
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL UpdateCandidate(?,?,?,?)}")) {
            stmt.setString(1, fields[0]);
            stmt.setString(2, fields[1]);
            stmt.setInt(3, Integer.parseInt(fields[2]));
            stmt.setString(4, fields[3]);
            stmt.executeUpdate();
            return "Candidate Updated Successfully";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String deleteCandidate(String data) {
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL DeleteCandidate(?)}")) {
            stmt.setString(1, data.trim());
            stmt.executeUpdate();
            return "Candidate Deleted Successfully";
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String getAllCandidates() {
        StringBuilder sb = new StringBuilder();
        try (Connection conn = getConnection();
             CallableStatement stmt = conn.prepareCall("{CALL GetAllCandidate()}");
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                sb.append(rs.getString("candidatecnic")).append(",")
                        .append(rs.getString("candidatename")).append(",")
                        .append(rs.getInt("partyid")).append(",")
                        .append(rs.getString("seatnumber")).append("\n");
            }
            return sb.toString();
        } catch (SQLException e) {
            return "Error: " + e.getMessage();
        }
    }

  private static String insertVote(String data) {
    String[] fields = data.split(",");
    if (fields.length != 4) return "Invalid Data for Vote";

    try (Connection conn = getConnection();
         CallableStatement stmt = conn.prepareCall("{CALL InsertVote(?, ?, ?, ?)}")) {

        stmt.setString(1, fields[0]); // votercnic
        stmt.setString(2, fields[1]); // candidatecnic
        stmt.setString(3, fields[2]); // seatnumber

        // Parse the date string
        java.sql.Date voteDate = java.sql.Date.valueOf(fields[3]); // yyyy-MM-dd
        stmt.setDate(4, voteDate); // votedate

        int rows = stmt.executeUpdate();
        return (rows > 0) ? "Vote Cast Successfully" : "Vote NOT Cast";

    } catch (Exception e) {
        return "Error: " + e.getMessage();
    }
}

  private static String getAllVotes() {
    StringBuilder sb = new StringBuilder();
    try (Connection conn = getConnection();
         CallableStatement stmt = conn.prepareCall("{CALL GetAllVotes()}");
         ResultSet rs = stmt.executeQuery()) {

        while (rs.next()) {
            sb.append(rs.getString("votercnic")).append(",")
              .append(rs.getString("candidatecnic")).append(",")
              .append(rs.getString("seatnumber")).append(",")
              .append(rs.getDate("votedate").toString()).append("\n");
        }

    } catch (SQLException e) {
        return "Error: " + e.getMessage();
    }

    return sb.toString();
}

    private static String calculateAndSaveResults() {
        
         try (Connection conn = getConnection()) {

        // Step 1: Delete old results (if any)
        Statement clearStmt = conn.createStatement();
        clearStmt.executeUpdate("DELETE FROM electionresult");

        // Step 2: Count votes for each candidate
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT candidatecnic, COUNT(*) as total_votes FROM votes GROUP BY candidatecnic");

        // Step 3: Find max votes and build vote map
        Map<String, Integer> voteMap = new HashMap<>();
        int maxVotes = 0;

        while (rs.next()) {
            String cnic = rs.getString("candidatecnic");
            int votes = rs.getInt("total_votes");
            voteMap.put(cnic, votes);
            if (votes > maxVotes) {
                maxVotes = votes;
            }
        }

        // Step 4: Insert into electionresult table
        PreparedStatement insertStmt = conn.prepareStatement(
            "INSERT INTO electionresult (year, candidatecnic, total_votes, status) VALUES (?, ?, ?, ?)"
        );

        int currentYear = java.time.Year.now().getValue(); // current year

        for (Map.Entry<String, Integer> entry : voteMap.entrySet()) {
            String cnic = entry.getKey();
            int votes = entry.getValue();
            String status = (votes == maxVotes) ? "winner" : "loser";

            insertStmt.setInt(1, currentYear);
            insertStmt.setString(2, cnic);
            insertStmt.setInt(3, votes);
            insertStmt.setString(4, status);
            insertStmt.executeUpdate();
        }

        return "Election results calculated and saved successfully.";

    } catch (Exception e) {
        return "Error: " + e.getMessage();
    }
    }

    private static String fetchElectionResults() {
         try (Connection conn = getConnection()) {
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM electionresult");

        JSONArray arr = new JSONArray();

        while (rs.next()) {
            JSONObject obj = new JSONObject();
            obj.put("election_id", String.valueOf(rs.getInt("election_id")));
            obj.put("year", String.valueOf(rs.getInt("year")));
            obj.put("candidatecnic", rs.getString("candidatecnic"));
            obj.put("total_votes", String.valueOf(rs.getInt("total_votes")));
            obj.put("status", rs.getString("status"));

            arr.put(obj);
        }

        out.println(arr.toString());

    } catch (Exception e) {
        out.println("Error: " + e.getMessage());
    }
        return null;
    

}

   private static String verifyVoter(String data) {
    String[] parts = data.split(",");
    String cnic = parts[0];
    String password = parts[1];
    String status = "";

    try (Connection conn = getConnection()) {
        CallableStatement stmt = conn.prepareCall("{CALL VerifyVoter(?, ?)}");
        stmt.setString(1, cnic);
        stmt.setString(2, password);

        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            status = rs.getString("status");
        } else {
            status = "Invalid";
        }
    } catch (Exception e) {
        status = "Error: " + e.getMessage();
    }
    return status;
}

}
    


